﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var login = textBox1.Text;
            var password = textBox2.Text;

            if(IsValidData(login,password))
            {
                MessageBox.Show("Авторизация прошла успешно");
            }

            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }

        }

        private bool IsValidData(string login, string pswd)
        {
            DataBase dataBase = new DataBase();

            string stringQuery = $"select UserLogin, UserPassword from [User] where UserLogin = '{login}' and UserPassword = '{pswd}'";

            SqlCommand cmd = new SqlCommand(stringQuery, dataBase.getConnection());

            dataBase.openConnection();
            SqlDataReader reader = cmd.ExecuteReader();


            if(reader.HasRows)
            {
                return true;
            }

            return false;

        }

    }
}
